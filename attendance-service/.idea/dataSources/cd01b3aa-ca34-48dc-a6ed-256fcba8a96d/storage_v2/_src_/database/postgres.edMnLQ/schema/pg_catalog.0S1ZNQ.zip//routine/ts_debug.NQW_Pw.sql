create function ts_debug(config regconfig, document text, OUT alias text, OUT description text, OUT token text, OUT dictionaries regdictionary[], OUT dictionary regdictionary, OUT lexemes text[]) returns SETOF record
    stable
    strict
    parallel safe
    language sql
BEGIN ATOMIC
 SELECT tt.alias,
     tt.description,
     parse.token,
     ARRAY( SELECT (m.mapdict)::regdictionary AS mapdict
            FROM pg_ts_config_map m
           WHERE ((m.mapcfg = (ts_debug.config)::oid) AND (m.maptokentype = parse.tokid))
           ORDER BY m.mapseqno) AS dictionaries,
     ( SELECT (m.mapdict)::regdictionary AS mapdict
            FROM pg_ts_config_map m
           WHERE ((m.mapcfg = (ts_debug.config)::oid) AND (m.maptokentype = parse.tokid))
           ORDER BY (ts_lexize((m.mapdict)::regdictionary, parse.token) IS NULL), m.mapseqno
          LIMIT 1) AS dictionary,
     ( SELECT ts_lexize((m.mapdict)::regdictionary, parse.token) AS ts_lexize
            FROM pg_ts_config_map m
           WHERE ((m.mapcfg = (ts_debug.config)::oid) AND (m.maptokentype = parse.tokid))
           ORDER BY (ts_lexize((m.mapdict)::regdictionary, parse.token) IS NULL), m.mapseqno
          LIMIT 1) AS lexemes
    FROM ts_parse(( SELECT pg_ts_config.cfgparser
            FROM pg_ts_config
           WHERE (pg_ts_config.oid = (ts_debug.config)::oid)), ts_debug.document) parse(tokid, token),
     ts_token_type(( SELECT pg_ts_config.cfgparser
            FROM pg_ts_config
           WHERE (pg_ts_config.oid = (ts_debug.config)::oid))) tt(tokid, alias, description)
   WHERE (tt.tokid = parse.tokid);
END;

comment on function ts_debug(regconfig, text, out text, out text, out text, out regdictionary[], out regdictionary, out text[]) is 'debug function for text search configuration';

alter function ts_debug(regconfig, text, out text, out text, out text, out regdictionary[], out regdictionary, out text[]) owner to postgres;

